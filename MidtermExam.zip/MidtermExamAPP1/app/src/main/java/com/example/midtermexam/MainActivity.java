package com.example.midtermexam;

import androidx.appcompat.app.AppCompatActivity;

import android.media.Image;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void CalculateOnClick(View view){
        EditText inputH = findViewById(R.id.Height);
        EditText inputW = findViewById(R.id.Weight);

        if(!inputH.getText().toString().equals("") && !inputW.getText().toString().equals("")){
            float h = Float.parseFloat(inputH.getText().toString()) / 100.0f; //to meters
            float w = Float.parseFloat(inputW.getText().toString());

            float bmi = w / (h * h);

            TextView output = findViewById(R.id.OutPutView);
            output.setText(String.valueOf(bmi));

            TextView outPutState = findViewById(R.id.OutPutState);
            String state = "";
            int imgs = 0;
            ImageView img = findViewById(R.id.OutPutImage);
            if(bmi >= 35){
                state = "重度肥胖";
                imgs = R.drawable.heavy_fat;
            }else if(bmi >= 30){
                state = "中度肥胖";
                imgs = R.drawable.fat;
            }else if(bmi >= 27){
                state = "輕度肥胖";
                imgs = R.drawable.light_fat;
            }else if(bmi >= 24){
                state = "過重";
                imgs = R.drawable.overweight;
            }else if(bmi >= 18.5){
                state = "正常";
                imgs = R.drawable.normal;
            }else{
                state = "過輕";
                imgs = R.drawable.skinny;
            }
            img.setImageResource(imgs);
            outPutState.setText(state);
        }
    }

    public void ClearOnClick(View view){
        EditText inputH = findViewById(R.id.Height);
        EditText inputW = findViewById(R.id.Weight);
        EditText inputN = findViewById(R.id.Name);
        EditText inputA = findViewById(R.id.Age);
        inputH.setText(" ");
        inputW.setText(" ");
        inputA.setText(" ");
        inputN.setText(" ");

        TextView output = findViewById(R.id.OutPutView);
        output.setText("");

        TextView outPutState = findViewById(R.id.OutPutState);
        outPutState.setText("");

        ImageView img = findViewById(R.id.OutPutImage);
        img.setImageResource(R.drawable.bmi);
    }
}