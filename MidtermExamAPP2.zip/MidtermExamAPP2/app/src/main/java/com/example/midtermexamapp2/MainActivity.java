package com.example.midtermexamapp2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements CompoundButton.OnCheckedChangeListener{

    float addToWaterMount = 0; //要增加的水量
    float currentGoal = 2000; //當前目標
    float currentAmount = 0; //當前進度
    int[] checkIDs = {R.id.onehundred, R.id.twohundred, R.id.threehundred, R.id.fourhundred, R.id.fivehundred};
    //選項
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        for (int id : checkIDs) { //設置選項物件的監聽
            CheckBox chb = findViewById(id);
            chb.setOnCheckedChangeListener(this);
        }

    }

    @Override
    public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
        //一次只選一個選項
        if(compoundButton.getId() == R.id.onehundred){
            if(compoundButton.isChecked()){
                addToWaterMount = 100;
                for (int id : checkIDs) {
                    CheckBox chb = findViewById(id);
                    if(id != R.id.onehundred) {
                        chb.setChecked(false);
                    }
                }
            }
        }else if(compoundButton.getId() == R.id.twohundred){
            if(compoundButton.isChecked()){
                addToWaterMount = 200;
                for (int id : checkIDs) {
                    CheckBox chb = findViewById(id);
                    if(id != R.id.twohundred) {
                        chb.setChecked(false);
                    }
                }
            }
        }else if(compoundButton.getId() == R.id.threehundred){
            if(compoundButton.isChecked()) {
                addToWaterMount = 300;
                for (int id : checkIDs) {
                    CheckBox chb = findViewById(id);
                    if (id != R.id.threehundred) {
                        chb.setChecked(false);
                    }
                }
            }
        }else if(compoundButton.getId() == R.id.fourhundred){
            if(compoundButton.isChecked()) {
                addToWaterMount = 400;
                for (int id : checkIDs) {
                    CheckBox chb = findViewById(id);
                    if (id != R.id.fourhundred) {
                        chb.setChecked(false);
                    }
                }
            }
        }else{
            if(compoundButton.isChecked()) {
                addToWaterMount = 500;
                for (int id : checkIDs) {
                    CheckBox chb = findViewById(id);
                    if (id != R.id.fivehundred) {
                        chb.setChecked(false);
                    }
                }
            }
        }
    }

    public void OnRecordClick(View view){ //執行紀錄
        ProgressBar bar = findViewById(R.id.ProgressBar);

        if(bar.getProgress() < 100){
            float p = (addToWaterMount/currentGoal)*100; //將水量值轉換成百分比
            TextView t = findViewById(R.id.percent);
            TextView pro = findViewById(R.id.CurrentProgress);

            int res = bar.getProgress() + (int)p; //原本的百分比加上後來增加的百分比
            bar.setProgress(res,true);
            t.setText(String.valueOf(res)+"%"); //將百分比顯示在頁面

            float prog = (res / 100.0f) * currentGoal;
            pro.setText(String.valueOf((int)prog)+"/");

            addToWaterMount = 0; //歸零

            for (int id : checkIDs) { //取消點擊狀態
                CheckBox chb = findViewById(id);
                chb.setChecked(false);
            }
        }

        if(bar.getProgress() >= 100){ //超出範圍
            bar.setProgress(100);
            TextView t = findViewById(R.id.percent);
            t.setText("100%");
        }
    }

    public void OnNewRecordClick(View view){ //更改目標時
        TextView oldGoal = findViewById(R.id.currentGoal);
        EditText newGoal = findViewById(R.id.enterNewGoal);
        ProgressBar bar = findViewById(R.id.ProgressBar);
        TextView t = findViewById(R.id.percent);

        if(!newGoal.getText().toString().equals("")){
            int newG = Integer.parseInt(newGoal.getText().toString());
            if(newG >= 2000){
                float r = (bar.getProgress() / 100.0f) * currentGoal; //還原成原本的毫升數值
                float res = r / (float)newG * 100;
                currentGoal = newG;

                t.setText(String.valueOf(res)); //更新百分比
                bar.setProgress((int)res,true); //更新進度
                oldGoal.setText(String.valueOf(newG)); //更新當前目標
            }
        }

        if(bar.getProgress() >= 100){ //超出範圍
            bar.setProgress(100);
            t.setText("100%");
        }

        newGoal.setText("");
    }
}